package q1.extract_method.refactored;

import java.util.List;

public class A {
   Node m1(List<Node> nodes, String p) {
	  // TODO: Your answer
      extractedMethod(nodes, p);
      // other implementation
      return null;
   }

   Edge m2(List<Edge> edgeList, String p) {
      // TODO: Your answer
	   extractedMethod(edgeList, p);
      // other implementation
      return null;
   }

   // TODO: Your answer
   <E> void extractedMethod(List<E> list, String p ) {
	   for ( E object : list) {
		   Node tempNode = null;
		   Edge tempEdge = null;
		   if (object instanceof Node)
		   {
			   tempNode = (Node)object;
		   }
		   else if (object instanceof Edge)
		   {
			   tempEdge = (Edge)object;
		   }
		   if (tempNode == null)
		   {
			   if (tempEdge.contains(p))
			   {
				   System.out.println(p);
			   }
		   }
		   else if (tempEdge == null)
		   {
			   if (tempNode.contains(p))
			   {
				   System.out.println(p);
			   }
		   }
		}
   }
}

class Node {
   String name;

   public boolean contains(String p) {
      return name.contains(p);
   }
}

class Edge {
   String name;

   public boolean contains(String p) {
       return name.contains(p);
   }
}