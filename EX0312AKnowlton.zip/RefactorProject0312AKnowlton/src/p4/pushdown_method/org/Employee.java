package p4.pushdown_method.org;

public class Employee {
	private String saleQuota;

	String getSaleQuota() {
		return this.saleQuota;
	}
}
